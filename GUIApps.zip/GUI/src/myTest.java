import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.GridBagLayout;
import javax.swing.JTextField;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class myTest extends JFrame {

	private JPanel contentPane;
	private JTextField given1_field;
	private JTextField given2_field;
	private JButton btnNewButton;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					myTest frame = new myTest();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public myTest() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		GridBagLayout gbl_contentPane = new GridBagLayout();
		gbl_contentPane.columnWidths = new int[]{0, 0, 0};
		gbl_contentPane.rowHeights = new int[]{0, 0, 0, 0, 0};
		gbl_contentPane.columnWeights = new double[]{0.0, 1.0, Double.MIN_VALUE};
		gbl_contentPane.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		contentPane.setLayout(gbl_contentPane);
		
		given1_field = new JTextField();
		given1_field.setText("Give a number");
		GridBagConstraints gbc_given1_field = new GridBagConstraints();
		gbc_given1_field.insets = new Insets(0, 0, 5, 0);
		gbc_given1_field.anchor = GridBagConstraints.WEST;
		gbc_given1_field.gridx = 1;
		gbc_given1_field.gridy = 1;
		contentPane.add(given1_field, gbc_given1_field);
		given1_field.setColumns(10);
		
		given2_field = new JTextField();
		given2_field.setText("Give a number");
		GridBagConstraints gbc_given2_field = new GridBagConstraints();
		gbc_given2_field.insets = new Insets(0, 0, 5, 0);
		gbc_given2_field.anchor = GridBagConstraints.WEST;
		gbc_given2_field.gridx = 1;
		gbc_given2_field.gridy = 2;
		contentPane.add(given2_field, gbc_given2_field);
		given2_field.setColumns(10);
		
		btnNewButton = new JButton("ADD");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		GridBagConstraints gbc_btnNewButton = new GridBagConstraints();
		gbc_btnNewButton.gridx = 1;
		gbc_btnNewButton.gridy = 3;
		contentPane.add(btnNewButton, gbc_btnNewButton);
	}

}
